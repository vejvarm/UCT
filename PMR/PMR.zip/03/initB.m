K = 1;
T1 = 10;
T2 = 1;
B = 1;

denom = conv([T1 1 0],[T2 1]);

