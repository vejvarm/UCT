%% Rekurentn� metoda nejmen��ch �tverc�
%% d�le�it� parametry
% -- VZORKOV�N� A �AS --
Ts = 0.5;
tmax = 100;
tspan = 0:Ts:tmax;
Nt = length(tspan);

% --- VSTUPN� SIGN�L ---
% u = linspace(0,1,Nt)';
% u = ones(Nt,1);
u = [linspace(0,1,floor(Nt/2))'; ones(ceil(Nt/2),1)];
% u = rand(Nt,1);

% -- SKUTE�N� SOUSTAVA --
ka = 5;
Ta = 2;
eps = 0.1;
B = ka;
A = [Ta^2 2*eps*Ta 1];
[Bz,Az] = c2dm(B,A,Ts);

% -- IDENTIFIKOVAN� SOUSTAVA --
nb = length(nonzeros(Bz));
na = length(Az);
init_ratio = 0.1;  % z jak� ��sti dostupn�ch dat se bude prov�d�t inicializace matic B a P (B0,P0)

%% diskr�tn� p�enos skute�n� soustavy
Fz = tf(Bz,Az,Ts);

% odezva skute�n� soustavy na specificky vstupn� signal u v �asech tspan
y = lsim(Fz,u,tspan);
    
%% vykreslen� odezvy simulovan� soustavy
figure(1)
    subplot(211)
    stairs(tspan,y)
    hold on
    stairs(tspan,u)
    hold off
    title('Skute�n� soustava')
    xlabel('�as (s)')
    ylabel('y,u')
    legend('odezva soustavy (y)','vstupn� sign�l (u)')
     
%% inicializace identifikace
% inicializace matic B a P (B0,P0)
init_length = floor(init_ratio*length(y));  % d�lka inicializa�n�ch dat
u0 = u(1:init_length);
y0 = y(1:init_length);
[B0,P0] = calcBandP(nb,na,y0,u0);

%% identifikace metodou RMN�
figure(1)
    subplot(212)
for i = init_length:length(y)-na
    % identifikace parametr� pomoc� RMN�
    [Bi,Ai] = rmnc(nb,na,y(i:i+na-1),u(i:i+nb),B0,P0);
    
    % simulace soustavy s identifikovan�mi parametry
    Fzi = tf(Bi',Ai',Ts);
    yi = lsim(Fzi,u,tspan);
    
    % vykreslen� identifikovan� soustavy
    stairs(tspan,yi)
    drawnow
end
    title('Identifikovan� soustava')
    xlabel('�as (s)')
    ylabel('yi')

% suma �tverc� odchylek
R = sumsqr(yi - y);

%% vykreslen� posledn�ch identifikovan�ch parametr�
figure(2)
    set(2,'DefaultlineLineWidth',2)
    plot(tspan,y,'-b',tspan,yi,'-.r')
    xlabel('�as (s)')
    ylabel('y')
    title(sprintf('Porovn�n� skute�n� a identifikovan� soustavy (R = %.2f)',R))
    legend('odezva skute�n� soustavy','odezva identifikovan� soustavy')

