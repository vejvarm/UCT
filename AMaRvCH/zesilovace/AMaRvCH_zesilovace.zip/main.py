from mpl_toolkits import mplot3d

from collections import namedtuple

import os
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt


def plot_results(df, x='U1 (V)', y='U2 (V)', title='', secondary_y=None, y_teor=None, styles=('bo', 'r-', 'g-')):
    ax = [None] * 2
    fig, ax[0] = plt.subplots()

    ax[0].plot(df[x], df[y], styles[0], label=y[1] if isinstance(y, list) else y)
    if isinstance(y_teor, np.ndarray):
        ax[0].plot(df[x], y_teor, styles[2], label=y[1] + ' (teor.)' if isinstance(y, list) else y + ' (teor.)')

    ax[0].set_xlabel(x)
    ax[0].set_ylabel(y)

    if secondary_y:
        ax[1] = ax[0].twinx()
        ax[1].plot(df[x], df[secondary_y], styles[1], label=secondary_y)
        ax[1].set_ylabel(secondary_y)

        lines = ax[0].get_lines() + ax[1].get_lines()
    else:
        lines = ax[0].get_lines()

    ax[0].legend(lines, [line.get_label() for line in lines])

    ax[0].set_title(title)
    ax[0].grid(True, which='major')

    return fig, ax


def df_from_xlsx(file='mereni - zesilovace.xlsx'):
    dataframe = pd.read_excel(file)
    DF = namedtuple('DF', 'g11_z10, g11_z100, g12, g13, g14, g15, g21, g22, g23, g24_rz100k, g24_rz10k')

    # nacteni dat
    df_g11_z10 = dataframe.iloc[1:10, 1:4]
    df_g11_z100 = dataframe.iloc[1:10, 4:7]
    df_g12 = dataframe.iloc[13:22, 1:4]
    df_g13 = dataframe.iloc[26:34, 1:4]
    df_g14 = dataframe.iloc[41:57, 1:4]
    df_g15 = dataframe.iloc[60:66, 1:3]
    df_g21 = dataframe.iloc[5:21, 12:15]
    df_g22 = dataframe.iloc[24:35, 12:14]
    df_g23 = dataframe.iloc[39:45, 12:14]
    df_g24_rz100k = dataframe.iloc[49:62, 12:14]
    df_g24_rz10k = dataframe.iloc[49:64, 14:16]

    # nazvy sloupcu
    df_g11_z10.columns = ['U1 (V)', 'U2 (V)', 'Z ~ -10']
    df_g11_z100.columns = ['U1 (V)', 'U2 (V)', 'Z ~ -100']
    df_g12.columns = ['U1 (V)', 'U2 (V)', 'Z ~ 11']
    df_g13.columns = ['R ($\Omega$)', 'U1 (V)', 'U2 (V)']
    df_g14.columns = ['U1a (V)', 'U1b (V)', 'Suma (V)']
    df_g15.columns = ['I_vst (mA)', 'U_vyst (V)']
    df_g21.columns = ['U1 (V)', 'U3 (V)', 'Rozdil (V)']
    df_g22.columns = ['cas (hh:mm:ss)', 'U2 (V)']
    df_g23.columns = ['U1 (V)', 'U2 (V)']
    df_g24_rz100k.columns = ['U1 (V)', 'U2 (V)']
    df_g24_rz10k.columns = ['U1 (V)', 'U2 (V)']

    # naplneni namedtuple
    df = DF(g11_z10=df_g11_z10, g11_z100=df_g11_z100, g12=df_g12, g13=df_g13, g14=df_g14, g15=df_g15,
            g21=df_g21, g22=df_g22, g23=df_g23, g24_rz100k=df_g24_rz100k, g24_rz10k=df_g24_rz10k)

    return df


def process_g11(df, savefig=False, folder='./figures', extention='.pdf'):
    """G1.1 Invertující zesilovač"""
    fields_z10 = list(df.g11_z10)
    fields_z100 = list(df.g11_z100)

    # teoreticke vypocty
    R1 = 1000
    R2_z10 = 10000
    R2_z100 = 100000

    # z10
    u1_z10 = np.array(df.g11_z10[fields_z10[0]])
    u2_z10_t = -R2_z10 * u1_z10 / R1

    # z100
    u1_z100 = np.array(df.g11_z100[fields_z100[0]])
    u2_z100_t = -R2_z100 * u1_z100 / R1

    # vykreslení
    plot_results(df.g11_z10,
                 title=r'Invertující zesilovač (Z ~ -10)',
                 secondary_y=fields_z10[2],
                 y_teor=u2_z10_t)

    if savefig:
        plt.savefig(os.path.join(folder, 'g11_z10') + extention, dpi=300)  # save the figure

    plot_results(df.g11_z100,
                 title=r'Invertující zesilovač (Z ~ -100)',
                 secondary_y=fields_z100[2],
                 y_teor=u2_z100_t)

    if savefig:
        plt.savefig(os.path.join(folder, 'g11_z100') + extention, dpi=300)  # save the figure


def process_g12(df, savefig=False, folder='./figures', extention='.pdf'):
    """G1.2 Neinvertující zesilovač"""
    fields = list(df.g12)

    # teoreticke vypocty
    R1 = 1000
    R2 = 10000

    # z10
    u1 = np.array(df.g12[fields[0]])
    u2_t = (1 + R2 / R1) * u1

    # vykreslení
    plot_results(df.g12,
                 title=r'Neinvertující zesilovač (Z ~ 11)',
                 secondary_y=fields[2],
                 y_teor=u2_t)

    if savefig:
        plt.savefig(os.path.join(folder, 'g12') + extention, dpi=300)  # save the figure


def process_g13(df, savefig=False, folder='./figures', extention='.pdf'):
    """G1.3 Napěťový sledovač"""
    fields = list(df.g13)

    # teoreticke vypocty
    u1 = np.array(df.g13[fields[1]])
    u2_t = u1

    # vykreslení
    fig, ax = plot_results(df.g13, x=fields[0], y=fields[1:],
                           title='Napěťový sledovač',
                           y_teor=u2_t)

    lines = ax[0].get_lines()
    lines[0].set_label('U1 (V)')
    lines[1].set_color('red')
    lines[1].set_linestyle('-')
    ax[0].legend(lines, [line.get_label() for line in lines])

    if savefig:
        plt.savefig(os.path.join(folder, 'g13') + extention, dpi=300)  # save the figure


def process_g14(df, savefig=False, folder='./figures', extention='.pdf'):
    """G1.4 Sumační zesilovač"""
    fields = list(df.g14)

    u1 = np.reshape(np.array(df.g14[fields[0]]), (4, -1))
    u2 = np.reshape(np.array(df.g14[fields[1]]), (4, -1))
    suma = np.reshape(np.array(df.g14[fields[2]]), (4, -1))

    # teoreticky vypocet
    R1 = 1000  # ohm
    R2 = R1  # ohm
    R3 = 1000  # ohm

    u3_t = -R3 * (u1 / R1 + u2 / R2)

    # vykreslení
    ax = plt.axes(projection='3d')

    p_real = ax.scatter(u1, u2, suma, label='U3 (V)')  # skutecnost

    for i, row in enumerate(u3_t):
        p_teor, = ax.plot(u1[i, :], u2[i, :], row, '-g', label='U3 (V) (teor.)')  # teorie

    ax.set_xlabel(r'U1 (V)')
    ax.set_ylabel(r'U2 (V)')
    ax.set_zlabel(r'suma (V)')

    ax.set_title(r'Sumační zesilovač')
    ax.legend(handles=[p_real, p_teor])

    if savefig:
        plt.savefig(os.path.join(folder, 'g14') + extention, dpi=300)  # save the figure


def process_g15(df, savefig=False, folder='./figures', extention='.pdf'):
    """G1.5 Převodník proudu na napětí"""
    fields = list(df.g15)

    # teoreticke vypocty
    ivst = np.array(df.g15[fields[0]])
    uvyst_t = -ivst

    plot_results(df.g15, x=fields[0], y=fields[1], y_teor=uvyst_t, title=r'Převodník proudu na napětí')

    if savefig:
        plt.savefig(os.path.join(folder, 'g15') + extention, dpi=300)  # save the figure

def process_g21(df, savefig=False, folder='./figures', extention='.pdf'):
    """G2.1 Rozdílový zesilovač"""
    fields = list(df.g21)

    u1 = np.reshape(np.array(df.g21[fields[0]]), (4, -1))
    u2 = np.reshape(np.array(df.g21[fields[1]]), (4, -1))
    rozdil = np.reshape(np.array(df.g21[fields[2]]), (4, -1))

    # teoreticky vypocet
    R1 = 1000  # ohm
    R2 = 10000  # ohm
    R3 = R1  # ohm
    R4 = R2  # ohm

    u3_t = ((R1 + R2) / (R3 + R4) * R4 * u2 - R2 * u1) / R1

    # vykreslení
    ax = plt.axes(projection='3d')

    p_real = ax.scatter(u1, u2, rozdil, label='U3 (V)')  # skutecnost

    for i, row in enumerate(u3_t):
        p_teor, = ax.plot(u1[i, :], u2[i, :], row, '-g', label='U3 (V) (teor.)')  # teorie

    ax.set_xlabel(r'U1 (V)')
    ax.set_ylabel(r'U2 (V)')
    ax.set_zlabel(r'rozdil (V)')

    ax.set_title(r'Diferenční zesilovač (Z ~ 10)')
    ax.legend(handles=[p_real, p_teor])

    if savefig:
        plt.savefig(os.path.join(folder, 'g21') + extention, dpi=300)  # save the figure


def process_g22(df, savefig=False, folder='./figures', extention='.pdf'):
    """G2.2 Integrační zesilovač"""
    fields = list(df.g22)

    # převod na datetime
    df.g22[fields[0]] = pd.to_datetime(df.g22[fields[0]], format='%H:%M:%S')

    # teoreticke vypocty
    R = 100000  # ohm
    C = 14.1 * 10 ** -6  # F
    u1 = 0.2  # V
    u2_0 = 0.001  # V

    t = np.array(df.g22[fields[0]].dt.minute * 60 + df.g22[fields[0]].dt.second)  # cas trvani pokusu v sekundach
    u2_t = -u2_0 - 1 / R / C * u1 * t  # V

    # vykreslení
    plot_results(df.g22, x=fields[0], y=fields[1], y_teor=u2_t, title=r'Integrační zesilovač')

    if savefig:
        plt.savefig(os.path.join(folder, 'g22') + extention, dpi=300)  # save the figure


def process_g23(df, savefig=False, folder='./figures', extention='.pdf'):
    """G2.3 Komparátor bez hystereze"""
    # teoreticky vypocet
    U2max = 15  # V
    U2min = -15  # V
    UR = 5  # V
    R1 = 1000  # ohm
    RR = 1000  # ohm

    u1 = np.linspace(4, 5.2, 50)
    u2_t = np.array([U2max if u1[i] < UR else U2min for i in range(len(u1))])

    # vykreslení
    fig, ax = plot_results(df.g23, title=r'Komparátor bez hystereze', styles=['bo-'])

    ax[0].plot(u1, u2_t, '-g', label='U2 (V) teor')
    lines = ax[0].get_lines()
    ax[0].legend(lines, [line.get_label() for line in lines])

    if savefig:
        plt.savefig(os.path.join(folder, 'g23') + extention, dpi=300)  # save the figure


def komp_s_hysterezi(R1, RZ, u1, UR, U2min, U2max):
    """vypocet vystupu komparatoru s hysterezi"""
    # inicializace
    u2_t = np.zeros_like(u1)

    # hystereze
    UH = R1 / (R1 + RZ) * (U2max - U2min)

    # vypocet u2
    for i in range(len(u1)):
        if u1[i] <= (UR - UH):
            u2_t[i] = U2max
        elif u1[i] >= (UR + UH):
            u2_t[i] = U2min
        else:
            u2_t[i] = u2_t[i - 1]

    return u2_t


def process_g24(df, savefig=False, folder='./figures', extention='.pdf'):
    """G2.4 Komparátor s hysterezí"""
    fields_rz100k = list(df.g24_rz100k)
    fields_rz10k = list(df.g24_rz10k)

    # teoreticke vypocty
    # A (RZ = 100kohm)
    U2max = 15  # V
    U2min = -15  # V
    UR = 5  # V
    R1 = 1000  # ohm
    RR = 1000  # ohm
    RZ = 100000  # ohm

    # vstupni napeti
    U1min = min(df.g24_rz100k[fields_rz100k[0]])
    U1max = max(df.g24_rz100k[fields_rz100k[0]])
    u1 = np.hstack((np.linspace(U1min, U1max, 25), np.linspace(U1max, U1min, 25)))

    # vystupni napeti
    u2_t = komp_s_hysterezi(R1, RZ, u1, UR, U2min, U2max)

    # vykreslení
    fig, ax = plot_results(df.g24_rz100k, title=r'Komparátor s hysterezí ($R_Z$ = 100 k$\Omega$)', styles=['bo-'])

    ax[0].plot(u1, u2_t, '-g', label='U2 (V) (teor.)')
    lines = ax[0].get_lines()
    ax[0].legend(lines, [line.get_label() for line in lines])

    if savefig:
        plt.savefig(os.path.join(folder, 'g24_rz100k') + extention, dpi=300)  # save the figure

    # B (RZ = 10kohm)
    RZ = 10000

    # vstupni napeti
    U1min = min(df.g24_rz10k[fields_rz10k[0]]) - 2
    U1max = max(df.g24_rz10k[fields_rz10k[0]]) + 2.5
    u1 = np.hstack((np.linspace(U1min, U1max, 25), np.linspace(U1max, U1min, 25)))

    # vystupni napeti
    u2_t = komp_s_hysterezi(R1, RZ, u1, UR, U2min, U2max)

    fig, ax = plot_results(df.g24_rz10k, title=r'Komparátor s hysterezí ($R_Z$ = 10 k$\Omega$)', styles=['bo-'])

    ax[0].plot(u1, u2_t, '-g', label='U2 (V) (teor.)')
    lines = ax[0].get_lines()
    ax[0].legend(lines, [line.get_label() for line in lines])

    if savefig:
        plt.savefig(os.path.join(folder, 'g24_rz10k') + extention, dpi=300)  # save the figure


if __name__ == '__main__':
    df = df_from_xlsx()

    savefig = False
    folder = './figures'
    extention = '.pdf'

    if not os.path.isdir(folder):
        os.mkdir(folder)

    process_g11(df, savefig=savefig, folder=folder, extention=extention)  # G1.1 Invertující zesilovač
    process_g12(df, savefig=savefig, folder=folder, extention=extention)  # G1.2 Neinvertující zesilovač
    process_g13(df, savefig=savefig, folder=folder, extention=extention)  # G1.3 Napěťový sledovač
    process_g14(df, savefig=savefig, folder=folder, extention=extention)  # G1.4 Sumační zesilovač
    process_g15(df, savefig=savefig, folder=folder, extention=extention)  # G1.5 Převodník proudu na napětí
    process_g21(df, savefig=savefig, folder=folder, extention=extention)  # G2.1 Rozdílový zesilovač
    process_g22(df, savefig=savefig, folder=folder, extention=extention)  # G2.2 Integrační zesilovač
    process_g23(df, savefig=savefig, folder=folder, extention=extention)  # G2.3 Komparátor bez hystereze
    process_g24(df, savefig=savefig, folder=folder, extention=extention)  # G2.4 Komparátor s hysterezí

    plt.show()
